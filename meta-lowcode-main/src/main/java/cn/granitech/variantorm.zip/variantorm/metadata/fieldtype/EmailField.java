package cn.granitech.variantorm.metadata.fieldtype;

public class EmailField extends TextField {
    public EmailField() {
    }

    public String getName() {
        return "Email";
    }
}
