package cn.granitech.variantorm.dbmapping;


import cn.granitech.variantorm.metadata.ID;
import cn.granitech.variantorm.metadata.MetadataManager;
import cn.granitech.variantorm.pojo.Entity;
import cn.granitech.variantorm.pojo.Field;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class DBMappingHelper {

    public static void updateMetaEntityRecord(DataSource dataSource, Entity entity) {
        String sql = "UPDATE `t_meta_entity` SET `label`=?, `layoutable`=?,  `listable`=?, `tags`=? WHERE `name`=? ";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

        jdbcTemplate.update(sql, entity.getLabel(), entity.isLayoutable(), entity.isListable(), entity.getTags(), entity.getName());
    }

    public static boolean checkFieldExists(DataSource dataSource, int entityCode, String fieldName) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = " SELECT count(*) FROM `t_meta_field` where `entityCode`=? AND `name`=? ";

        Integer fieldCount = jdbcTemplate.queryForObject(sql, Integer.class, entityCode, fieldName);
        return fieldCount!=null && fieldCount > 0;
    }

    public static void insertMetaEntityRecord(DataSource dataSource, Entity entity) {
        String sql = "INSERT INTO `t_meta_entity` (`entityId`,`name`,`label`,`physicalName`,`entityCode`,  `detailEntityFlag`, `mainEntity`, `layoutable`, `listable`, `authorizable`, `shareable`, `assignable`, `tags`)  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) \n";
        ID newID = ID.newID(1);
        int entityCode = entity.getEntityCode() == null ? newID.getEntityCode() : entity.getEntityCode();
        String mainEntityName = entity.getMainEntity() == null ? null : entity.getMainEntity().getName();
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        Object[] param = new Object[13];
        param[0] = newID;
        param[1] = entity.getName();
        param[2] = entity.getLabel();
        param[3] = entity.getPhysicalName();
        param[4] = entityCode;
        param[5] = entity.isDetailEntityFlag();
        param[6] = mainEntityName;
        param[7] = entity.isLayoutable();
        param[8] = entity.isListable();
        param[9] = entity.isAuthorizable();
        param[10] = entity.isShareable();
        param[11] = entity.isAssignable();
        param[12] = entity.getTags();
        jdbcTemplate.update(sql, param);
        entity.setEntityCode(entityCode);
    }

    public static void deleteMetaFieldRecord(DataSource dataSource, int entityCode, String fieldName) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = " DELETE FROM `t_meta_field` WHERE `entityCode`=? AND `name`=? ";

        jdbcTemplate.update(sql, entityCode, fieldName);
    }

    public static void updateMetaFieldRecord(DataSource dataSource, int entityCode, Field field) {
        String sql = "UPDATE `t_meta_field` SET `label`=?, `description`=?, `displayOrder`=?, `nullable`=?,  `creatable`=?, `updatable`=?, `idFieldFlag`=?, `nameFieldFlag`=?, `mainDetailFieldFlag`=?,  `defaultMemberOfListFlag`=?, `referTo`=?, `referenceSetting`=?, `fieldViewModel`=?  WHERE `entityCode`=? AND `name`=?";
        String referName = "";
        if (field.getReferTo() != null) {
            referName = field.getReferTo().stream().map(Entity::getName).collect(Collectors.joining(","));

        }
        ObjectMapper mapper = new ObjectMapper();
        String fieldViewModel = null;
        String referenceSetting = null;

        try {
            if (field.getFieldViewModel() != null) {
                fieldViewModel = mapper.writeValueAsString(field.getFieldViewModel());
            }

            if (StringUtils.isBlank(fieldViewModel) || "null".equalsIgnoreCase(fieldViewModel)) {
                fieldViewModel = null;
            }

            if (field.getReferenceSetting() != null) {
                referenceSetting = mapper.writeValueAsString(field.getReferenceSetting());
            }

            if (StringUtils.isBlank(referenceSetting) || "null".equalsIgnoreCase(referenceSetting)) {
                referenceSetting = null;
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        Object[] paraArray = new Object[15];
        paraArray[0] = field.getLabel();
        paraArray[1] = field.getDescription();
        paraArray[2] = field.getDisplayOrder();
        paraArray[3] = field.isNullable();
        paraArray[4] = field.isCreatable();
        paraArray[5] = field.isUpdatable();
        paraArray[6] = field.isIdFieldFlag();
        paraArray[7] = field.isNameFieldFlag();
        paraArray[8] = field.isMainDetailFieldFlag();
        paraArray[9] = field.isDefaultMemberOfListFlag();
        paraArray[10] = referName;
        paraArray[11] = fieldViewModel;
        paraArray[12] = referenceSetting;
        paraArray[13] = entityCode;
        paraArray[14] = field.getName();
        jdbcTemplate.update(sql, paraArray);
    }

    public static void setNameFieldOfEntity(DataSource dataSource, Entity entity, Field field) {
        JdbcTemplate jdbcTemplate =  new JdbcTemplate(dataSource);
        String updateSql = " UPDATE `t_meta_field` SET `nameFieldFlag`=0 WHERE `entityCode`=? ";

        jdbcTemplate.update(updateSql, entity.getEntityCode());
        String sql = " UPDATE `t_meta_field` SET `nameFieldFlag`=1 WHERE `entityCode`=? AND `name`=? ";

        jdbcTemplate.update(sql, entity.getEntityCode(), field.getName());
    }

    public static void insertMetaFieldRecord(DataSource dataSource, int entityCode, Field field) {
        String sql = "INSERT INTO `t_meta_field` (`fieldId`, `entityCode`,`name`,`label`,`physicalName`,`type`,  `description`, `displayOrder`, `nullable`, `creatable`, `updatable`, `idFieldFlag`, `nameFieldFlag`,  `mainDetailFieldFlag`, `defaultMemberOfListFlag`, `referTo`, `referenceSetting`, `fieldViewModel`)  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        ID newID = ID.newID(2);
        String referName = "";
        if (field.getReferTo() != null) {
            referName = field.getReferTo().stream().map(Entity::getName).collect(Collectors.joining(","));

        }
        ObjectMapper mapper = new ObjectMapper();
        String fieldViewModel = null;
        String referenceSetting = null;

        try {
            if (field.getFieldViewModel() != null) {
                fieldViewModel = mapper.writeValueAsString(field.getFieldViewModel());
            }

            if (StringUtils.isBlank(fieldViewModel) || "null".equalsIgnoreCase(fieldViewModel)) {
                fieldViewModel = null;
            }

            if (field.getReferenceSetting() != null) {
                referenceSetting = mapper.writeValueAsString(field.getReferenceSetting());
            }

            if (StringUtils.isBlank(referenceSetting) || "null".equalsIgnoreCase(referenceSetting)) {
                referenceSetting = null;
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        Object[] paraArray = new Object[18];
        paraArray[0] = newID.getId();
        paraArray[1] = entityCode;
        paraArray[2] = field.getName();
        paraArray[3] = field.getLabel();
        paraArray[4] = field.getPhysicalName();
        paraArray[5] = field.getType().getName();
        paraArray[6] = field.getDescription();
        paraArray[7] = field.getDisplayOrder();
        paraArray[8] = field.isNullable();
        paraArray[9] = field.isCreatable();
        paraArray[10] = field.isUpdatable();
        paraArray[11] = field.isIdFieldFlag();
        paraArray[12] = field.isNameFieldFlag();
        paraArray[13] = field.isMainDetailFieldFlag();
        paraArray[14] = field.isDefaultMemberOfListFlag();
        paraArray[15] = referName;
        paraArray[16] = referenceSetting;
        paraArray[17] = fieldViewModel;
        jdbcTemplate.update(sql, paraArray);
    }


    public static void loadMetadataFromDB(DataSource dataSource, MetadataManager mdm) {
        JdbcTemplate a = new JdbcTemplate(dataSource);
        List<Entity> entityList = a.query(" SELECT * FROM `t_meta_entity` order by entityCode ", new BeanPropertyRowMapper<>(Entity.class));
        List<Field> fieldList = a.query(" SELECT * FROM `t_meta_field` ", new BeanPropertyRowMapper<>(Field.class));

        Map<Integer, List<Field>> fileMap = fieldList.stream().collect(Collectors.groupingBy(Field::getEntityCode));

        entityList.forEach(entity -> {

            List<Field> fields = fileMap.get(entity.getEntityCode());
            entity.setFieldSet(fields);
            entity.setMetadataManager(mdm);
            if(!entity.isDetailEntityFlag()){
                entity.setMainEntity(null);
            }
            if(entity.isDetailEntityFlag() && entity.getMainEntity()!=null){
                Entity mainEntity = entity.getMainEntity();
                mainEntity.getDetailEntitySet().add(entity);

            }
            mdm.addEntity(entity);

        });




    }

    public static void deleteMetaEntityRecord(DataSource dataSource, String entityName, int entityCode) {
        JdbcTemplate a;
        JdbcTemplate var10000 = a = new JdbcTemplate(dataSource);
        String entitySql = " DELETE FROM `t_meta_entity` WHERE `name`=? ";

        var10000.update(entitySql, entityName);
        String fieldSql = " DELETE FROM `t_meta_field` WHERE `entityCode`=? ";

        a.update(fieldSql, entityCode);
    }



    public static boolean checkEntityExists(DataSource dataSource, String entityName) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = " SELECT count(*) FROM `t_meta_entity` where `name`=? ";
        Integer entityCount = jdbcTemplate.queryForObject(sql, Integer.class, entityName);
        return entityCount!=null && entityCount > 0;
    }

    public static boolean checkTableExists(DataSource dataSource, String tableName) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sqlStr = " SHOW TABLES LIKE '%s' ";
        String sql = String.format(sqlStr, tableName);
        List<String> list = jdbcTemplate.queryForList(sql, String.class);
        return list.size() > 0;
    }
}
