package cn.granitech.variantorm.metadata.fieldtype;

public class MoneyField extends DecimalField {
    public MoneyField() {
    }

    public String getName() {
        return "Money";
    }
}
