package cn.granitech.variantorm.metadata.fieldtype;

public class TextAreaField extends TextField {
    public String getName() {
        return "TextArea";
    }
}
