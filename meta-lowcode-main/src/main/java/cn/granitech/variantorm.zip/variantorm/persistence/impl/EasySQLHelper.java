package cn.granitech.variantorm.persistence.impl;



import cn.granitech.variantorm.constant.MetaEntityColumns;
import cn.granitech.variantorm.persistence.PersistenceManager;
import cn.granitech.variantorm.persistence.queryCompiler.SelectStatement;
import cn.granitech.variantorm.pojo.Pagination;
import cn.granitech.variantorm.pojo.QuerySchema;
import cn.granitech.variantorm.util.MDHelper;

public class EasySQLHelper {
//    public static SelectStatement generateRawSql(PersistenceManager pm, QuerySchema querySchema, Pagination pagination) {
//        String a = ALLATORIxDEMO(querySchema, pagination);
//        return pm.getSqlCompiler().compileEasySql(pm.getMetadataManager(), a);
//    }

    public static String getCountSql(String rawSql) {
        StringBuilder a = new StringBuilder();
        a.append(" SELECT count(*) ");
        StringBuilder var10000;
        if (!rawSql.contains(" ORDER BY ")) {
            if (rawSql.contains(" LIMIT ")) {
                var10000 = a;
                a.append(rawSql, rawSql.indexOf(" FROM "), rawSql.indexOf(" LIMIT "));
            } else {
                var10000 = a;
                a.append(rawSql.substring(rawSql.indexOf(" FROM ")));
            }
        } else {
            var10000 = a;
            a.append(rawSql, rawSql.indexOf(" FROM "), rawSql.indexOf(" ORDER BY "));
        }

        return var10000.toString();
    }

    public EasySQLHelper() {
    }


}
