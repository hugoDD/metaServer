package cn.granitech.variantorm.metadata.fieldtype;

public class PercentField extends IntegerField {
    public String getName() {
        return "Percent";
    }
}

