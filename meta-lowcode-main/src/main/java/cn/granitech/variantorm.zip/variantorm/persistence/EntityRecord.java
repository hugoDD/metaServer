package cn.granitech.variantorm.persistence;


import cn.granitech.variantorm.metadata.ID;
import cn.granitech.variantorm.pojo.Entity;

import java.util.Map;
import java.util.Set;

public interface EntityRecord {
    void setFieldValue(String var1, Object var2);

    boolean isModified();

    void setFieldLabel(String var1, String var2);

    Set<String> getModifiedFieldSet();

    boolean labelValueExists(String var1);

    ID id();

    Map<String, String> getLabelsMap();

    Entity getEntity();

    void setValuesMap(Map<String, Object> var1);

    void copyFrom(EntityRecord var1);

    Map<String, Object> getValuesMap();

    EntityRecord fromJson(String var1);

    boolean isModified(String var1);

    void setNotModified();

    boolean isNull(String var1);

    <T> T getFieldValue(String var1);

    String asJson();

    String getFieldLabel(String var1);

    String getName();
}
