package cn.granitech.variantorm.metadata.fieldtype;

public class UrlField extends TextField {
    public String getName() {
        return "Url";
    }
}
