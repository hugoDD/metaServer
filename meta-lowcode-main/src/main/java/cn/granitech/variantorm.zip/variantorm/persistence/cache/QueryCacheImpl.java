package cn.granitech.variantorm.persistence.cache;

public class QueryCacheImpl {
}
