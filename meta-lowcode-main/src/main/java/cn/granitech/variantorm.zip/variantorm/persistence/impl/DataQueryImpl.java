package cn.granitech.variantorm.persistence.impl;


import cn.granitech.variantorm.persistence.DataQuery;
import cn.granitech.variantorm.persistence.PersistenceManager;
import cn.granitech.variantorm.persistence.cache.QueryCache;
import cn.granitech.variantorm.pojo.Pagination;
import cn.granitech.variantorm.pojo.QuerySchema;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataQueryImpl implements DataQuery {
    private final PersistenceManager L;

    private static final String F = " SQL_CALC_FOUND_ROWS ";

    private final QueryCache D;

    private static final String ALLATORIxDEMO = "; SELECT FOUND_ROWS(); ";

    public List<Map<String, Object>> query(QuerySchema querySchema, Pagination pagination) {
        super();
        List<Map<String, Object>> a;
        querySchema.ALLATORIxDEMO((QuerySchema)new HashMap<>(), (Map<String, Object>)querySchema, pagination, a);
        return (List<Map<String, Object>>)this;
    }

    public DataQueryImpl(PersistenceManager pm, QueryCache queryCache) {
        this.L =pm;
        this.D = queryCache;
    }

    public List<Map<String, Object>> query(QuerySchema querySchema, Pagination pagination, Map<String, Object> paramMap) {
        ALLATORIxDEMO(paramMap);
        ALLATORIxDEMO(querySchema, paramMap, pagination, arrayList);
        ArrayList<Map<String, Object>> arrayList;
        return arrayList = new ArrayList<>();
    }
}
