package cn.granitech.variantorm.dbmapping;


import cn.granitech.variantorm.constant.ReservedFields;
import cn.granitech.variantorm.constant.SystemEntities;
import cn.granitech.variantorm.constant.SystemEntityCodes;
import cn.granitech.variantorm.dbmapping.ddl.DBDDL;
import cn.granitech.variantorm.dbmapping.ddl.MySQLDDL;
import cn.granitech.variantorm.exception.DuplicateEntityException;
import cn.granitech.variantorm.exception.DuplicateFieldException;
import cn.granitech.variantorm.exception.LicenseException;
import cn.granitech.variantorm.metadata.FieldType;
import cn.granitech.variantorm.metadata.MetadataManager;
import cn.granitech.variantorm.metadata.fieldtype.FieldTypes;
import cn.granitech.variantorm.persistence.PersistenceManager;
import cn.granitech.variantorm.pojo.Entity;
import cn.granitech.variantorm.pojo.Field;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.util.Collections;
import java.util.Set;

import static cn.granitech.variantorm.constant.SystemEntityCodes.DEPARTMENT_CODE;
import static cn.granitech.variantorm.constant.SystemEntityCodes.USER_CODE;

public class DBMappingManager {
    private final MetadataManager metadataManager;
    private final DBDDL db;
    private final DataSource dataSource;
    private final PersistenceManager persistenceManager;

    public void createField(int entityCode, Field field) {
        if (DBMappingHelper.checkFieldExists(this.dataSource, field.getOwner().getEntityCode(), field.getName())) {
            throw new DuplicateFieldException("字段" + field.getName() + "已存在");
        } else {
            if (field.getType() != FieldTypes.REFERENCELIST) {
                this.db.createFieldColumn(field);
            }

            DBMappingHelper.insertMetaFieldRecord(this.dataSource, entityCode, field);
            this.metadataManager.addField(field.getOwner().getName(), field);
        }
    }

    public void deleteEntity(String entityName) {
        if (!SystemEntities.isInternalEntity(entityName) && !SystemEntities.isSystemEntity(entityName)) {
            Entity a = this.metadataManager.getEntity(entityName);
            this.db.deleteEntityTable(a);
            DBMappingHelper.deleteMetaEntityRecord(this.dataSource, entityName, a.getEntityCode());
            this.metadataManager.removeEntity(entityName);
        } else {
            throw new IllegalStateException("系统实体、内部实体不可删除!");
        }
    }

    public void updateEntity(Entity entity) {
        DBMappingHelper.updateMetaEntityRecord(this.dataSource, entity);
        this.metadataManager.updateEntity(entity);
    }

    public DBMappingManager(DataSource dataSource, MetadataManager metadataManager, PersistenceManager persistenceManager) {
        this.dataSource = dataSource;
        this.metadataManager = metadataManager;
        this.persistenceManager = persistenceManager;
        this.db = new MySQLDDL(dataSource);
        DBMappingHelper.loadMetadataFromDB(dataSource, this.metadataManager);
    }

    public void createApprovalSystemFields(Entity entity) {
        int entityCode = entity.getEntityCode();
        Field approvalConfigField = new Field();
        approvalConfigField.setName("approvalConfigId");
        approvalConfigField.setLabel("审批流程");
        approvalConfigField.setPhysicalName("approvalConfigId");
        approvalConfigField.setType(FieldTypes.REFERENCE);
        approvalConfigField.setReferTo(Collections.singleton(metadataManager.getEntity(SystemEntityCodes.APPROVAL_CONFIG_CODE)));
        approvalConfigField.setNullable(true);
        approvalConfigField.setCreatable(false);
        approvalConfigField.setUpdatable(false);
        approvalConfigField.setOwner(entity);
        this.createField(entityCode, approvalConfigField);
        Field approvalStatusField = new Field();
        approvalStatusField.setName("approvalStatus");
        approvalStatusField.setLabel("审批状态");
        approvalStatusField.setPhysicalName("approvalStatus");
        approvalStatusField.setType(FieldTypes.STATUS);
        approvalStatusField.setNullable(true);
        approvalStatusField.setCreatable(false);
        approvalStatusField.setUpdatable(false);
        approvalStatusField.setOwner(entity);
        this.createField(entityCode, approvalStatusField);
        Field lastApprovedField = new Field();
        lastApprovedField.setName("lastApprovedBy");
        lastApprovedField.setLabel("最近审批人");
        lastApprovedField.setPhysicalName("lastApprovedBy");
        lastApprovedField.setType(FieldTypes.REFERENCE);
        lastApprovedField.setReferTo(Collections.singleton(metadataManager.getEntity(USER_CODE)));
        lastApprovedField.setNullable(true);
        lastApprovedField.setCreatable(false);
        lastApprovedField.setUpdatable(false);
        lastApprovedField.setOwner(entity);
        this.createField(entityCode, lastApprovedField);
        Field lastApprovedOnField = new Field();
        lastApprovedOnField.setName("lastApprovedOn");
        lastApprovedOnField.setLabel("最近审批时间");
        lastApprovedOnField.setPhysicalName("lastApprovedOn");
        lastApprovedOnField.setType(FieldTypes.DATETIME);
        lastApprovedOnField.setNullable(true);
        lastApprovedOnField.setCreatable(false);
        lastApprovedOnField.setUpdatable(false);
        lastApprovedOnField.setOwner(entity);
        this.createField(entityCode, lastApprovedOnField);
        Field lastApprovalRemarkField = new Field();
        lastApprovalRemarkField.setName("lastApprovalRemark");
        lastApprovalRemarkField.setLabel("最近审批批注");
        lastApprovalRemarkField.setPhysicalName("lastApprovalRemark");
        lastApprovalRemarkField.setType(FieldTypes.TEXTAREA);
        lastApprovalRemarkField.setNullable(true);
        lastApprovalRemarkField.setCreatable(false);
        lastApprovalRemarkField.setUpdatable(false);
        lastApprovalRemarkField.setOwner(entity);
        this.createField(entityCode, lastApprovalRemarkField);
    }

    public void deleteField(String entityName, String fieldName) {
        if (ReservedFields.isReservedField(entityName, fieldName)) {
            throw new IllegalStateException("系统保留字段不可删除!");
        } else {
            Field field = this.metadataManager.getEntity(entityName).getField(fieldName);
            int entityCode = field.getOwner().getEntityCode();
            this.db.deleteFieldColumn(field);
            DBMappingHelper.deleteMetaFieldRecord(this.dataSource, entityCode, fieldName);
            this.metadataManager.removeField(entityName, fieldName);
        }
    }

    public void updateField(int entityCode, Field field) {
        if (entityCode != field.getEntityCode()) {
            throw new IllegalArgumentException("entity code mismatched!");
        }
        Entity entity = this.metadataManager.getEntity(entityCode);
        Field currentField = entity.getField(field.getName());
        field.setName(currentField.getName());
        field.setPhysicalName(currentField.getPhysicalName());
        field.setType(currentField.getType());
        field.setIdFieldFlag(currentField.isIdFieldFlag());
        field.setMainDetailFieldFlag(currentField.isMainDetailFieldFlag());
        if (field.getType() == FieldTypes.REFERENCE) {
            field.setReferTo(currentField.getReferTo());
        }

        DBMappingHelper.updateMetaFieldRecord(this.dataSource, entityCode, field);
        this.metadataManager.updateField(entity.getName(), field.getName(), field);
    }

    public void createEntity(Entity entity) {
        if (this.persistenceManager != null && this.persistenceManager.getLicenseInfo().getEntityLimit() != null) {
            Integer entityLimit = this.persistenceManager.getLicenseInfo().getEntityLimit();
            JdbcTemplate jdbcTemplate = new JdbcTemplate(this.dataSource);
            Integer count = jdbcTemplate.queryForObject(" SELECT count(*) FROM `t_meta_entity` where entityCode > 1000 ", Integer.class);
            if (count != null && count >= entityLimit) {
                String entityLimitSql = "当前系统版本最多支持%d个自定义实体，已超出此限制！";
                throw new LicenseException(String.format(entityLimitSql, entityLimit));
            }
        }

        if (DBMappingHelper.checkEntityExists(this.dataSource, entity.getName())) {
            throw new DuplicateEntityException("实体" + entity.getName() + "已存在!");
        } else if (DBMappingHelper.checkTableExists(this.dataSource, entity.getPhysicalName())) {
            throw new IllegalStateException("数据库表" + entity.getPhysicalName() + "已存在!");
        } else {
            this.db.createEntityTable(entity);
            DBMappingHelper.insertMetaEntityRecord(this.dataSource, entity);
            this.metadataManager.addEntity(entity);
            Field idField = entity.getIdField();
            DBMappingHelper.insertMetaFieldRecord(this.dataSource, entity.getEntityCode(), idField);
            this.metadataManager.addField(entity.getName(), idField);


            createSysDefaulField(entity, "createdOn", "创建时间", FieldTypes.DATE, null);
            createSysDefaulField(entity, "modifiedOn", "最近修改时间", FieldTypes.DATE, null);
            createSysDefaulField(entity, "modifiedBy", "修改用户", FieldTypes.REFERENCE, Collections.singleton(metadataManager.getEntity(USER_CODE)));

//            this.ALLATORIxDEMO(entity, this.L, "createdBy", "创建用户", "User", false, false, false);
//            this.e(entity, this.L, "modifiedOn","最近修改时间", true, false, false);
//            this.ALLATORIxDEMO(entity, this.L, "modifiedBy", "修改用户", "User", true, false, false);
            if (entity.isAuthorizable() || entity.isAssignable()) {
                createSysDefaulField(entity, "ownerUser", "所属用户", FieldTypes.REFERENCE, Collections.singleton(metadataManager.getEntity(USER_CODE)));
                createSysDefaulField(entity, "ownerDepartment", "所属部门", FieldTypes.REFERENCE, Collections.singleton(metadataManager.getEntity(DEPARTMENT_CODE)));
//                this.ALLATORIxDEMO(entity, this.L, "ownerUser", "所属用户", "User", false, false, false);
//                this.ALLATORIxDEMO(entity, this.L, "ownerDepartment", "所属部门", "Department", false, false, false);
            }

        }
    }

    private Field createSysDefaulField(Entity ownerEntity, String name, String label, FieldType fieldType, Set<Entity> entitySet) {
        Field field = new Field();
        field.setName(name);
        field.setLabel(label);
        field.setPhysicalName(name);
        field.setType(fieldType);
        field.setReferTo(entitySet);
        field.setNullable(false);
        field.setCreatable(false);
        field.setUpdatable(false);
        field.setOwner(ownerEntity);

        DBMappingHelper.insertMetaFieldRecord(this.dataSource, ownerEntity.getEntityCode(), field);
        this.metadataManager.addField(ownerEntity.getName(), field);
        return field;
    }

    public DBMappingManager(DataSource dataSource, MetadataManager mdm) {
        this.dataSource = dataSource;
        this.metadataManager = mdm;
        this.persistenceManager = null;
        this.db = new MySQLDDL(dataSource);
        DBMappingHelper.loadMetadataFromDB(dataSource, this.metadataManager);
    }
}
