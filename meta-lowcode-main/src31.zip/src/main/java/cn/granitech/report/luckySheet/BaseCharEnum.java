package cn.granitech.report.luckySheet;

public interface BaseCharEnum {
    String getCode();

    String getName();
}



