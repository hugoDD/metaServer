package cn.granitech.variantorm.persistence.license;


import cn.granitech.variantorm.HelloWorld;
import cn.granitech.variantorm.exception.InvalidEntityException;
import cn.hutool.crypto.symmetric.SymmetricCrypto;
import com.alibaba.fastjson2.JSONObject;
import com.alibaba.fastjson2.JSONWriter;
import java.util.Map;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class OfflineLicenseHelper {
    private static final String D = "Meta_Code_hhr@~!";
    private static final int ALLATORIxDEMO = 128;

    public static Map<String, Object> decryptData(String encryptedData) {
        try {
            byte[] a = OfflineLicenseHelper.ALLATORIxDEMO(D);
            SecretKeySpec a2 = new SecretKeySpec(a, HelloWorld.ALLATORIxDEMO(",u>"));
            return (Map)JSONObject.parseObject((String)new SymmetricCrypto(InvalidEntityException.ALLATORIxDEMO("_!MK['\\KN/]7+4\u007f\u0000z\rp\u0003"), (SecretKey)a2).decryptStr(encryptedData), Map.class);
        }
        catch (Exception a) {
            throw new RuntimeException(HelloWorld.ALLATORIxDEMO("\u898e\u5bf6\u5b3a\u7b16\u4e5f\u5901\u8d48"), a);
        }
    }

    private static /* synthetic */ byte[] ALLATORIxDEMO(String passphrase) {
        try {
            SecretKeyFactory a = SecretKeyFactory.getInstance(InvalidEntityException.ALLATORIxDEMO("N&U XVI\rj\fV\t\u007f\u0007M,_U"));
            PBEKeySpec a2 = new PBEKeySpec(passphrase.toCharArray(), new byte[16], 10000, 128);
            return a.generateSecret(a2).getEncoded();
        }
        catch (Exception a) {
            throw new RuntimeException(HelloWorld.ALLATORIxDEMO("\u79e8\u94c8\u6d0e\u7572\u5901\u8d48"), a);
        }
    }

    public static void main(String[] stringArray) throws Exception {
        System.out.println(InvalidEntityException.ALLATORIxDEMO("n=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G\u0014G>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D=n=D>D>D>D>G=D=D>D=D>D>G=D=G=D=G=D=G>D=G=D>D>D>D>G\u0014G>D>D>D>G>G>G>D>G>D>G>G>D=D>G>G>G>G>D=D>D>D>D>D=n=D>D>D>D=G=D=D>D=D>D=G=D>G>D=D=D=G>D>G>D>D>D>D>G\u0014G>D>D>D>G>G>G=G>G=G>G>G>D=D>G=G>G>G>G=G>D>D>D>D=n=D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>G\u0014G>+|\u0002k\u0017}\u0005j\rq\n>\u0006gD_\br\u0005j\u000bl\r>+|\u0002k\u0017}\u0005j\u000blDhS0R> [)QD=n=D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>G\u0014G>D>D>D>D>D>\fj\u0010n^1Ki\u0013iJ\u007f\br\u0005j\u000bl\r0\u0007q\t>D>D>D>D>D>D=n=D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>D>G\u0014G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=G=n"));
        Map<String, Object> a = OfflineLicenseHelper.decryptData(HelloWorld.ALLATORIxDEMO("v9i\u0019q X\f\b\u0006X\u0002\u001f%}\u001eI'x?b\"|\u001av\u0017`5|F_=Y\u0000I\u0006R\u001fY\u0003\u0007\u0019S^x x?[\u000bY_`\u0002R,a%T.\u0003\u001e\u0006/^\u0019\u001b\u000bi\u0019x\u001aE\u000fg\u001fg\n`\u0017v_Q^s \u0004;V]e\u0018_:f\"s\u000f\u0007\u0006S_XF_/w.\u0005(f\u0015hFY5i/D>B\u001av4\u0000\u0000CFg&B\u0014h\u0015\u00059WY@\\~\u000eu\u001f\\>y*g<\u00007{]\u0006\u001b\u007f7\u0001\u001dT\u001e\u001f#D!F\u001d\u0006\u000b[\tS_[\u0017h\u001ey\u0004\u0006\u0018t9z=x\u0005Q%rX\u0000#UFf\u000b\u001f\u001e@\u0003\u0003*Q'F=_\na\bz!T\"w\u001cbZ~ZJ eU|&H=|\u001d~.S'~\"T\u0006i\fA*{\u0000\u007f_j;xY\u0004=W4j'c\u0002VZi\u001b\\Zq>\u0007\u001fh\\A*w)z,\rP"));
        System.out.println(a);
    }

    public static String encryptData(Map<String, Object> data) {
        try {
            byte[] a = OfflineLicenseHelper.ALLATORIxDEMO(D);
            SecretKeySpec a2 = new SecretKeySpec(a, InvalidEntityException.ALLATORIxDEMO("%[7"));
            String a3 = JSONObject.toJSONString(data, (JSONWriter.Feature[])new JSONWriter.Feature[0]);
            return new SymmetricCrypto(HelloWorld.ALLATORIxDEMO("q(cBu.rB`&s>\u0005=Q\tT\u0004^\n"), (SecretKey)a2).encryptBase64(a3);
        }
        catch (Exception a) {
            throw new RuntimeException(InvalidEntityException.ALLATORIxDEMO("\u52be\u5ba2\u5be7\u8c05\u592f\u8d41"), a);
        }
    }
}

