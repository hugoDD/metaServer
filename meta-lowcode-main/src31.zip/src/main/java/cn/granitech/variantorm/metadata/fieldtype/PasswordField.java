package cn.granitech.variantorm.metadata.fieldtype;

public class PasswordField extends TextField {
    public String getName() {
        return "Password";
    }
}

