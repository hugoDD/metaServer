//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package cn.granitech.variantorm.persistence.cache;

import cn.granitech.variantorm.metadata.ID;
import cn.granitech.variantorm.persistence.EntityRecord;
import cn.granitech.variantorm.persistence.PersistenceManager;
import cn.granitech.variantorm.pojo.IDName;
import cn.granitech.variantorm.pojo.OptionModel;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static cn.granitech.variantorm.constant.SystemEntities.ReferenceCache;

public class QueryCacheImpl implements QueryCache {
    private final Map<String, IDName> idNameMap;
    private final OptionCacheManager optionCacheManager;
    private final Map<String, List<IDName>> userRoleMap;
    private final Map<String, List<IDName>> approvalTaskCcToMap;
    private final TagCacheManager tagCacheManager;
    private final PersistenceManager pm;
    private final Map<String, List<IDName>> approvalTaskApprover;


    private  void initIdNameMap() {
        this.idNameMap.clear();
        List<EntityRecord> list = this.pm.createRecordQuery().query(ReferenceCache, null, null, null, null);
        for (EntityRecord entityRecord : list) {
            IDName idName = new IDName(entityRecord.getFieldValue("referenceId"), entityRecord.getFieldValue("recordLabel"));
            this.idNameMap.put(entityRecord.getFieldValue("referenceId").toString(),idName);
        }
    }

    @Override
    public TagCacheManager getTagCacheManager() {
        return this.tagCacheManager;
    }

    @Override
    public void deleteIDName(String refId) {
    }


    private  void initApprovalTaskApprover() {

        approvalTaskApprover.clear();

        List<EntityRecord> userRecords = pm.createRecordQuery().query("User", null, null, null, null, "userId","userName");
        Map<ID, EntityRecord> map = new HashMap<>();
        for (EntityRecord record : userRecords) {
            map.put(record.id(), record);
        }
        List<EntityRecord> entityRecords = this.pm.createRecordQuery().query("ReferenceListMap", "([entityName] = 'ApprovalTask') and ([fieldName] = 'approver')", null, null, null);
        for (EntityRecord record : entityRecords) {
            ID objectId = record.getFieldValue("objectId");
            List<IDName> idNames = this.approvalTaskApprover.computeIfAbsent(objectId.getId(), k -> new ArrayList<>());
            ID toId = record.getFieldValue("toId");
            EntityRecord entityRecord = map.get(toId);
            idNames.add(new IDName(entityRecord.id(), entityRecord.getName()));
        }
    }

    @Override
    public void reloadReferenceListCache(String entityName, String refFieldName, String recordId) {
        if ("User".equals(entityName) && "roles".equals(refFieldName)) {
            this.initUserRoleMap();
            return;
        }
        if ("ApprovalTask".equals(entityName) && "approver".equals(refFieldName)) {
            this.initApprovalTaskApprover();
            return;
        }
        if ("ApprovalTask".equals(entityName) && "ccTo".equals(refFieldName)) {
            this.initApprovalTaskCcToMap();
        }
    }


    private  void initUserRoleMap() {
        userRoleMap.clear();

        List<EntityRecord> roleRecords = pm.createRecordQuery().query("Role", null, null, null, null,  "roleId","roleName");

        List<EntityRecord> userRecords = this.pm.createRecordQuery().query("User", null, null, null, null, "userId","userName");
        List<EntityRecord> referenceListMapRecords = this.pm.createRecordQuery().query("ReferenceListMap", "([entityName] = 'User') and ([fieldName] = 'roles')", null, null, null);
        for (EntityRecord entityRecord : userRecords) {
            ID userId = entityRecord.getFieldValue("userId");
            List<ID> toIds = this.getToIds(userId, referenceListMapRecords);
            if (toIds.size() == 0) {
                this.userRoleMap.put(userId.toString(), new ArrayList<>());
                continue;
            }
            List<IDName> idNames = new ArrayList<>();
            for (ID toId : toIds) {
                String roleName = this.getRoleName(toId, roleRecords);
                idNames.add(new IDName(toId, roleName));
            }
            this.userRoleMap.put(userId.toString(), idNames);
        }
    }

    @Override
    public void initIDName() {
    }

    @Override
    public IDName getIDName(String refId) {
        if (this.idNameMap.size() == 0) {
            this.initIdNameMap();
        }
        return this.idNameMap.get(refId);
    }

    @Override
    public void initIDNameList() {
    }

    @Override
    public OptionCacheManager getOptionCacheManager() {
        return this.optionCacheManager;
    }

    @Override
    public boolean updateIDName(IDName idName) {
        if (this.idNameMap.containsKey(idName.getId().toString())) {
            this.idNameMap.put(idName.getId().toString(), idName);
            return true;
        }
        return false;
    }

    public QueryCacheImpl(PersistenceManager pm) {

        this.idNameMap = new ConcurrentHashMap<>();
        this.userRoleMap = new ConcurrentHashMap<>();
        this.approvalTaskApprover = new ConcurrentHashMap<>();
        this.approvalTaskCcToMap = new ConcurrentHashMap<>();
        this.pm = pm;
        this.optionCacheManager = new OptionCacheManager(pm);
        this.tagCacheManager = new TagCacheManager(pm);
    }

    private  String getRoleName(ID roleId, List<EntityRecord> roleList) {
        for (EntityRecord a : roleList) {
            if (!roleId.equals(a.getFieldValue("roleId"))){
                continue;
            }
            return a.getFieldValue("roleName");
        }
        return null;
    }


    private  void initApprovalTaskCcToMap() {
       approvalTaskCcToMap.clear();

        List<EntityRecord> userRecords = pm.createRecordQuery().query("User", null, null, null, null,  "userId","userName");
        Map<ID, EntityRecord> userRecordMap = new HashMap<>();
        for (EntityRecord userRecord : userRecords) {
            userRecordMap.put(userRecord.id(), userRecord);
        }
        List<EntityRecord> referenceListMaps = this.pm.createRecordQuery().query("ReferenceListMap","([entityName] = 'ApprovalTask') and ([fieldName] = 'ccTo')", null, null, null);
        for (EntityRecord referenceListMapRecord : referenceListMaps) {
            ID objectId = referenceListMapRecord.getFieldValue("objectId");
            List<IDName> idNames = this.approvalTaskCcToMap.computeIfAbsent(objectId.toString(), k -> new ArrayList<>());
            ID toId = referenceListMapRecord.getFieldValue("toId");
            EntityRecord entityRecord = userRecordMap.get(toId);
            idNames.add(new IDName(entityRecord.id(), entityRecord.getName()));
        }
    }

    @Override
    public boolean updateIDNameList(String entityName, String refFieldName, String recordId, List<IDName> idNameList) {
        if ("User".equals(entityName) && "roles".equals(refFieldName)) {
            this.initUserRoleMap();
            return true;
        }
        if ("ApprovalTask".equals(entityName) && "approver".equals(refFieldName)) {
            this.initApprovalTaskApprover();
            return true;
        }
        if ("ApprovalTask".equals(entityName) && "ccTo".equals(refFieldName)) {
            this.initApprovalTaskCcToMap();
            return true;
        }
        return false;
    }

    private  List<ID> getToIds(ID userId, List<EntityRecord> userRolesList) {
        List<ID> toIds = new ArrayList<>();
        for (EntityRecord userRoleRecord : userRolesList) {
            if (!userId.equals(userRoleRecord.getFieldValue("objectId"))) {
                continue;
            }
            toIds.add(userRoleRecord.getFieldValue("toId"));
        }
        return toIds;
    }

    @Override
    public List<IDName> getIDNameList(String entityName, String refFieldName, String recordId) {
        if ("User".equals(entityName) && "roles".equals(refFieldName)) {
            if (this.userRoleMap.isEmpty()) {
                this.initUserRoleMap();
            }
            return this.userRoleMap.get(recordId);
        }
        if ("ApprovalTask".equals(entityName) && "approver".equals(refFieldName)) {
            if (this.approvalTaskApprover.isEmpty()) {
                this.initApprovalTaskApprover();
            }
            return this.approvalTaskApprover.get(recordId);
        }
        if ("ApprovalTask".equals(entityName) && "ccTo".equals(refFieldName)) {
            if (this.approvalTaskCcToMap.isEmpty()) {
                this.initApprovalTaskCcToMap();
            }
            return this.approvalTaskCcToMap.get(recordId);
        }
        return null;
    }

    @Override
    public OptionModel getStatus(String entityName, String fieldName, int statusValue) {
        for (OptionModel a : this.optionCacheManager.getStatuses(fieldName)) {
            if (a.getValue() != statusValue) continue;
            return a;
        }
        return null;
    }

    @Override
    public OptionModel getOption(String entityName, String fieldName, int optionValue) {
        for (OptionModel a : this.optionCacheManager.getOptions(entityName, fieldName)) {
            if (a.getValue() != optionValue) continue;
            return a;
        }
        return null;
    }
}
