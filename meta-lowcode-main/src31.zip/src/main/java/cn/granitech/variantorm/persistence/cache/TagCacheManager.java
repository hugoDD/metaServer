package cn.granitech.variantorm.persistence.cache;

import cn.granitech.variantorm.persistence.EntityRecord;
import cn.granitech.variantorm.persistence.PersistenceManager;
import cn.granitech.variantorm.persistence.RecordQuery;
import cn.granitech.variantorm.pojo.TagModel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TagCacheManager {
    private final PersistenceManager persistenceManager;
    private final Map<String, List<TagModel>> tagModelMap;

    public List<TagModel> getTags(String entityName, String fieldName) {
        if (this.tagModelMap.size() == 0) {
            this.initTagModelMap();
        }
        String key =  entityName+"_"+fieldName;
        if (!this.tagModelMap.containsKey( key)) {
            this.reloadTagsByField(entityName, fieldName);
        }
        if (this.tagModelMap.containsKey(key)) {
            return this.tagModelMap.get(key);
        }
        return new ArrayList<>();
    }

    public TagCacheManager(PersistenceManager persistenceManager) {

        this.tagModelMap = new HashMap<>();
        this.persistenceManager = persistenceManager;
    }

    public synchronized void reloadTagsByField(String entityName, String fieldName) {
        this.tagModelMap.remove((new StringBuilder()).insert(0, entityName).append('_').append(fieldName).toString());
        Map<String,Object> param = new HashMap<>();
        param.put("entityName",entityName);
        param.put("fieldName",fieldName);
        RecordQuery recordQuery = this.persistenceManager.createRecordQuery();
        String filter = "([entityName] = :entityName) and ([fieldName] = :fieldName)";
        String orderSql = "[entityName], [fieldName], [displayOrder]";
        List<EntityRecord> entityRecords = recordQuery.query("TagItem", filter, param, orderSql, null);
        for (EntityRecord entityRecord : entityRecords) {
            String value = entityRecord.getFieldValue("value");
            Integer displayOrder = entityRecord.getFieldValue("displayOrder");
            String key = entityName + "_" + fieldName;
            TagModel tagModel = new TagModel(value, displayOrder);
            if (this.tagModelMap.containsKey(key)) {
                this.tagModelMap.get(key).add(tagModel);
            } else {
                List<TagModel> list = new ArrayList<>();
                list.add(tagModel);
                this.tagModelMap.put(key, list);
            }
        }
    }

    private synchronized  void initTagModelMap() {
        List<EntityRecord> tagItemRecords = this.persistenceManager.createRecordQuery().query("TagItem", null, null, "[entityName], [fieldName], [displayOrder]", null);
        for (EntityRecord tagItemRecord : tagItemRecords) {
            String entityName = tagItemRecord.getFieldValue("entityName");
            String fieldName = tagItemRecord.getFieldValue("fieldName");
            String value = tagItemRecord.getFieldValue("value");
            Integer displayOrder = tagItemRecord.getFieldValue("displayOrder");
            String key = entityName+"_"+fieldName;
            TagModel tagModel = new TagModel(value, displayOrder);
            if (this.tagModelMap.containsKey(key)) {
                this.tagModelMap.get(key).add(tagModel);
                continue;
            }
            List<TagModel> list = new ArrayList<>();
            list.add(tagModel);
            this.tagModelMap.put(key, list);
        }
    }


}
