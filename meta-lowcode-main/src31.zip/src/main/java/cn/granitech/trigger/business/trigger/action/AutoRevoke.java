package cn.granitech.trigger.business.trigger.action;

import cn.granitech.web.pojo.Cascade;

import java.util.List;


public class AutoRevoke {
    private List<Cascade> items;

    public List<Cascade> getItems() {
        return this.items;
    }

    public void setItems(List<Cascade> items) {
        this.items = items;
    }
}



