package cn.granitech.trigger.business.trigger.action;


class GroupItem {
    private String sourceField;
    private String targetField;

    public String getSourceField() {
        return this.sourceField;
    }

    public void setSourceField(String sourceField) {
        this.sourceField = sourceField;
    }

    public String getTargetField() {
        return this.targetField;
    }

    public void setTargetField(String targetField) {
        this.targetField = targetField;
    }
}



