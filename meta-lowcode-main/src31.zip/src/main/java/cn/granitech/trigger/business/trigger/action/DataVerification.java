package cn.granitech.trigger.business.trigger.action;

import cn.granitech.web.pojo.filter.Filter;


public class DataVerification {
    String tipContent;
    Filter filter;

    public String getTipContent() {
        return this.tipContent;
    }

    public void setTipContent(String tipContent) {
        this.tipContent = tipContent;
    }

    public Filter getFilter() {
        return this.filter;
    }

    public void setFilter(Filter filter) {
        this.filter = filter;
    }
}



