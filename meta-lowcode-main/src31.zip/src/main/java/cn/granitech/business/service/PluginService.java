package cn.granitech.business.service;

import cn.granitech.business.plugins.trigger.TriggerService;

import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PluginService {
//    @Resource
//    private PluginUser pluginUser;
//    @Resource
//    private PluginOperator pluginOperator;

    public PluginService() {
    }

    public List<String> getPluginInfo() {
        return Collections.emptyList();
//        List<PluginInfo> pluginInfoList = this.pluginOperator.getPluginInfo();
//        return pluginInfoList.stream()
//                .filter((pluginInfo) -> pluginInfo.getPluginState().equals("STARTED"))
//                .map(PluginInfo::getPluginId).collect(Collectors.toList());
    }

    public TriggerService getTriggerService() {
        return null;//(TriggerService) this.pluginUser.getBean("metaTrigger", "triggerServiceImpl");
    }
}
