package cn.granitech.web.constant;

/**
 * @Description:
 * @Author: VDP 思南
 * @Date: 2020/8/28 12:27
 * @Version: 1.0
 */

public class SessionNames {

    public static final String LoginUserId = "loginUserId";
    public static final String DingTalkUserId = "dingTalkUserId";

}
