package cn.granitech.web.pojo;

public class User extends BasePojo {
}
