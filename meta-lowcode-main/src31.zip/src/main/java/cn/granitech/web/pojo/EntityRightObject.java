package cn.granitech.web.pojo;

public class EntityRightObject {
    private Boolean authorizable;
    private String entityLabel;
    private String entityName;
}
