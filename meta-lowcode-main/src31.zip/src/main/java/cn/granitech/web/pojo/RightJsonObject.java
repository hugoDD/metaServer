package cn.granitech.web.pojo;

public class RightJsonObject {
}
