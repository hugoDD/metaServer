package cn.granitech.web.pojo;

public class SystemParameters {
}
